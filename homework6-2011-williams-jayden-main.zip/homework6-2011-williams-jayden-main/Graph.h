#ifndef GRAPH_H
#define GRAPH_H
#include <iostream>
#include <vector>

#include "GraphInterface.h"
template<class LabelType> 
class Graph: public GraphInterface<LabelType>
{ 
  Graph();
  Graph(const LabelType& newData);
  
  private:
    int vertices, edges, weights[][];
    //nt getposition(); 
    //int getopenposition(); 
    //bool isvisited(); 

  public:

      int getNumVertices() const;
      int getNumEdges() const;
      //void display(vector<int> a, int n);
      bool add(LabelType start, LabelType end, int edgeWeight) ;
      //bool remove(LabelType start, LabelType end) ;
      //int getEdgeWeight(LabelType start, LabelType end) const ;
      //void depthFirstTraversal(LabelType start, void visit(LabelType&)) ;
      //void breadthFirstTraversal(LabelType start, void visit(LabelType&)) ;
        //~GraphInterface() { }
};
};
#include "Graph.cpp"
#endif