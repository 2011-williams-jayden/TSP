//Main Driver
//Date: 11/27/21
//Author: Jayden Williams
#include <iostream>
#include <time.h>
#define TOTALCITIES = 5
using namespace std;

int main()
{
    float graph[][TOTALCITIES] = { 
       { 0, 218.4, 518.2, 704.3, 438.8 },
       { 218.4, 0, 735.9,807.7, 568.8 },
       { 518.2, 735.9, 0, 829.1, 421.2 },
       { 704.3, 807.7, 829.1, 0, 1114.5 },
       {438.8, 568.8, 421.2, 1114.5, 0 }
       };
    int start = 0;
    float sol = solution(graph, start);
    cout << "Final Solution = " << sol << " Miles, which costs " << 40*sol << " gallons" << endl;
   return 0;
}
