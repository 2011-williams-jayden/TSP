#ifndef GRAPH_CPP
#define GRAPH_CPP
#define TOTALCITIES = 5

#include <iostream>
#include<bits/stdc++.h>
#include "Graph.h"

using namespace std;

template<class LabelType>
Graph<LabelType>::Graph()
{}

template<class LabelType>
Graph<LabelType>::Graph(const LabelType& newData)
{
	item = newData;

}

template<class LabelType>
int Graph<LabelType>:: getNumVertices() const
{
	return NumVertices;
}

template<class LabelType>
int Graph<LabelType>:: getNumEdges() const
{
	return NumEdges;
}

template<class LabelType> 
bool Graph<LabelType>::add(LabelType start, LabelType end, int edgeWeight);
{
	float city1pos, city2pos, TotalWeight;
	vertices[TOTALCITIES] = start;
	vertices[TOTALCITIES] = end;
	weights[city1pos][city2pos] = TotalWeight;
}

/*template<class LabelType> 
void Graph<LabelType>::display(vector<int> verticies, int n)
{
    for(int i=0; i<n; i++) 
	{
		cout << verticies[i] << " ";
    	cout << endl;
	}
}
